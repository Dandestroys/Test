import os
import logging
from googleapiclient.discovery import build
from pytube import YouTube

# Configure logging to save output to 'logs.txt'
logging.basicConfig(level=logging.DEBUG, filename='logs.txt', filemode='w',
                    format='%(asctime)s - %(levelname)s - %(message)s')
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Set up YouTube Data API and define the API key
API_KEY = 'AIzaSyDWTzTmRs8idEE8ZngKZw20oYrvqwx9P4w'  # Replace with your actual YouTube Data API key
youtube = build('youtube', 'v3', developerKey=API_KEY)

def download_video(video_url, download_format='mp4'):
    yt = YouTube(video_url)
    
    # Display available quality options
    print("Available quality options:")
    for stream in yt.streams.filter(progressive=True, file_extension='mp4').order_by('resolution'):
        print(f"{stream.resolution} - {stream.includes_audio_track} - {stream.fps}fps")

    # Choose a stream quality
    selected_quality = input("Enter the quality (e.g., 720p) you want to download: ")

    # Download the selected stream
    selected_stream = yt.streams.filter(res=selected_quality, file_extension='mp4').first()
    if selected_stream:
        selected_stream.download()
        print("Video downloaded successfully.")
    else:
        print(f"No {selected_quality} MP4 stream found for the video.")

def youtube_search(query, max_results=5, page_token=None):
    logging.debug(f"Searching for videos related to: {query}")
    request = youtube.search().list(
        part='snippet',
        q=query,
        type='video',
        maxResults=max_results,
        pageToken=page_token
    )

    response = request.execute()
    return response

# Main script logic
query = input("Enter the video you want to search for: ")
max_results = 5
page_token = None
while True:
    response = youtube_search(query, max_results, page_token)

    for i, item in enumerate(response.get('items', [])):
        print(f"{i + 1}. {item['snippet']['title']}")

    selection = input("Enter the number of the video you want to download, 'next' for more results, or 'exit' to quit: ")

    if selection.lower() == 'exit':
        break
    elif selection.lower() == 'next':
        page_token = response.get('nextPageToken')
    elif selection.isnumeric() and 1 <= int(selection) <= len(response.get('items', [])):
        selected_video = int(selection) - 1
        video_id = response.get('items', [])[selected_video]['id']['videoId']
        video_url = f'https://www.youtube.com/watch?v={video_id}'
        format_choice = input("Enter 'mp4' to download as video or 'mp3' to download as audio: ")
        download_video(video_url, download_format=format_choice)
    else:
        print("Invalid selection. Please try again.")import os
import logging
from googleapiclient.discovery import build
from pytube import YouTube

# Configure logging to save output to 'logs.txt'
logging.basicConfig(level=logging.DEBUG, filename='logs.txt', filemode='w',
                    format='%(asctime)s - %(levelname)s - %(message)s')
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Set up YouTube Data API and define the API key
API_KEY = 'AIzaSyDWTzTmRs8idEE8ZngKZw20oYrvqwx9P4w'  # Replace with your actual YouTube Data API key
youtube = build('youtube', 'v3', developerKey=API_KEY)

def download_video(video_url, download_format='mp4'):
    yt = YouTube(video_url)
    
    # Display available quality options
    print("Available quality options:")
    for stream in yt.streams.filter(progressive=True, file_extension='mp4').order_by('resolution'):
        print(f"{stream.resolution} - {stream.includes_audio_track} - {stream.fps}fps")

    # Choose a stream quality
    selected_quality = input("Enter the quality (e.g., 720p) you want to download: ")

    # Download the selected stream
    selected_stream = yt.streams.filter(res=selected_quality, file_extension='mp4').first()
    if selected_stream:
        selected_stream.download()
        print("Video downloaded successfully.")
    else:
        print(f"No {selected_quality} MP4 stream found for the video.")

def youtube_search(query, max_results=5, page_token=None):
    logging.debug(f"Searching for videos related to: {query}")
    request = youtube.search().list(
        part='snippet',
        q=query,
        type='video',
        maxResults=max_results,
        pageToken=page_token
    )

    response = request.execute()
    return response

# Main script logic
query = input("Enter the video you want to search for: ")
max_results = 5
page_token = None
while True:
    response = youtube_search(query, max_results, page_token)

    for i, item in enumerate(response.get('items', [])):
        print(f"{i + 1}. {item['snippet']['title']}")

    selection = input("Enter the number of the video you want to download, 'next' for more results, or 'exit' to quit: ")

    if selection.lower() == 'exit':
        break
    elif selection.lower() == 'next':
        page_token = response.get('nextPageToken')
    elif selection.isnumeric() and 1 <= int(selection) <= len(response.get('items', [])):
        selected_video = int(selection) - 1
        video_id = response.get('items', [])[selected_video]['id']['videoId']
        video_url = f'https://www.youtube.com/watch?v={video_id}'
        format_choice = input("Enter 'mp4' to download as video or 'mp3' to download as audio: ")
        download_video(video_url, download_format=format_choice)
    else:
        print("Invalid selection. Please try again.")